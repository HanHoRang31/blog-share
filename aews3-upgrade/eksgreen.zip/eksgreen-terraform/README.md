test for asset
